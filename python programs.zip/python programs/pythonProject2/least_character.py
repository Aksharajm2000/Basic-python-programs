string=input('Enter a string: ')

all_freq = {}
for char in string:
    if char in all_freq:
        all_freq[char] += 1
    else:
        all_freq[char] = 1
#res = max(all_freq, key=all_freq.get)
#print(str(res))
res = min(all_freq, key=all_freq.get)

print(str(res))
