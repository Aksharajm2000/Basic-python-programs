#Python program to count number of vowels using sets in given string
def count_vowels(string):
    vowel = set('aeiouAEIOU')
    count = 0
    for letter in string:
        if letter in vowel:
            count += 1
    print(count)

string = input("Enter a string: ")
count_vowels(string)
