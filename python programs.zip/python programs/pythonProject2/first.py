'''Python – Uppercase Half String'''

string = input("enter the string")

print("the original string is ",str(string))

half_string = len(string)//2

new_string = string[:half_string] + string[half_string:].upper()
print("the new string is ",new_string)