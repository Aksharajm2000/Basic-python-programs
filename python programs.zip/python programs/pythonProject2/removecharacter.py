# 3 Ways to remove i’th character from string in Python

def remove_ith_character(s, i):
    if i == 0:
        return s[1:]

    return s[0] + remove_ith_character(s[1:], i - 1)


string = input("enter the string")
new_string = remove_ith_character(string, 2)
print(new_string)