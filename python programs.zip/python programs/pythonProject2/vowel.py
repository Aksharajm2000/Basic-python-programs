'''Python | Program to accept the strings which contains all vowels'''

def vowel(s):
    for i in s:
        if i in 'aeiou':
            print(s)
            return True
        else:
            return False

string = input('Enter a string: ')
print(vowel(string))

