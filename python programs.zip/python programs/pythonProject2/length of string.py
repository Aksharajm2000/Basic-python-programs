# 4  Find length of a string in python (4 ways)

'''s = input("enter the string")

len(s)
print(len(s))'''

''' using for loop
def length_of_string(str):
    count = 0
    for i in str:
        count += 1
    return count

str = input("enter the string")
print(length_of_string(str))'''

'''using sum
def findLen(string):
	return sum( 1 for i in string)

string = input("enter the string")
print(findLen(string))'''


# using while loop

def findLen(str):
    count = 0
    while str[count:]:
        count += 1
    return count


str = input("enter the string")
print(findLen(str))
