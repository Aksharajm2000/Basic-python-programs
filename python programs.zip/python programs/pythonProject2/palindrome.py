# 1.Python program to check whether the string is Symmetrical or Palindrome

def is_palindrome(s):
    return s == s[::-1]  # slicing to reverse the string for Palindrome


def is_symmetrical(s):
    mid = len(s) // 2
    return s[:mid] == s[-mid:]  # slicing to split the string for Symmetric


string = str(input("enter the string"))

if is_palindrome(string):
    print("is palindrome")

else:
    print("is not palindrome")

if is_symmetrical(string):
    print("is Symmetrical")

else:
    print("is not Symmetrical")
