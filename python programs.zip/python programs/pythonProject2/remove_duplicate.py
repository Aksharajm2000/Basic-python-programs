#Python Program to remove all duplicates from a given string

string = input("Enter a string: ")
result = ""
for char in string:
    if char not in result:
        result = result+char  #add the character to the result if char not found in the string
print(result)
k = set(result)
print(k)

'''string = input("Enter a string: ")

s = set(string)
print(s)'''


