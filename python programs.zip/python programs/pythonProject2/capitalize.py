'''• Python program to capitalize the first and last character of each word in a string'''

string = input("enter the string")
a = string.split()
new_string = []
for i in a:
    x=i[0].upper()+i[1:-1]+i[-1].upper()
    new_string.append(x)
new_string = " ".join(new_string)
print(new_string)