# 2. Reverse words in a given String in Python
# input string
'''string = input("enter the string")
# reversing words in a given string
s = string.split()[::-1]
l = []
for i in s:
    # appending reversed words to l
    l.append(i)
# printing reverse words
print(" ".join(l))

or'''

def reverse(s):
    s = s.split()[::-1]
    l = []
    for i in s:
        l.append(i)
    print(" ".join(l))


t = input("enter the string")
reverse(t)


