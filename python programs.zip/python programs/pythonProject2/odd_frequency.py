string = input("Enter a string: ")

s = set(string)
res = []
for i in s:
    if (string.count(i)%2!=0):
        res.append(i)

print(str(res))