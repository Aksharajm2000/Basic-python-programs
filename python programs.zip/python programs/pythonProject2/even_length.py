# 6 Python program to print even length words in a string
# using split()
def even_length(s):
    s = s.split(' ')

    for i in s:
        if len(i) % 2 == 0:
            print(i)


a = input("enter the string")
even_length(a)

