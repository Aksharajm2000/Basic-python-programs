# 5 Python – Avoid Spaces in string length

string = input("enter the string")

count = 0
for i in string:
    if i == ' ':
        continue
    else:
        count+=1

print("the lenght is",count)
