'''Python | Count the Number of matching characters in a pair of string'''

def count_matches(str1, str2):
    return (len(set(str1).intersection(set(str2))))

string1 = input("Enter the first string: ")
string2 = input("Enter the second string: ")

no_of_common_characters = count_matches(string1, string2)
print(no_of_common_characters)