'''Python program to check if a string has at least one letter and one number'''

def check(s):
    flag_l = False
    flag_n = False
    for c in s:
        if c.isalpha():
            flag_l = True
        if c.isdigit():
            flag_n = True
    return flag_l and flag_n

string = input("Enter a string: ")
print(check(string))

