class Node:
    def __init__(self, data=None, next=None):
        self.data = data
        self.next = next


class Linkedlist:
    def __init__(self):
        self.head = None

    def insert_at_begining(self, data):
        node = Node(data, self.head)  # now node has data and address of previous head
        self.head = node  # now the head is new node

    def print(self):
        if self.head is None:
            print("linked list is empty")
            return

        temp = self.head  # this is temporary variable
        llstr = ''  # creating Linkedlist string to put a values
        while temp:
            llstr += str(temp.data) + '-->'  # appending data to the string  or we can use print(temp.data)
            temp = temp.next

        print(llstr)

    def insert_at_end(self, data):
        if self.head is None:
            self.head = Node(data, None)
            return

        temp = self.head
        while temp.next:
            temp = temp.next

        temp.next = Node(data, None)

    def insert_values(self, data_list):
        self.head = None
        for data in data_list:
            self.insert_at_end(data)

    def get_length(self):
        count = 0
        temp = self.head
        while temp:
            count += 1
            temp = temp.next
        return count

    def remove_at(self, index):
        if index < 0 or index >= self.get_length():
            raise Exception("invalid index")

        if index == 0:
            self.head = self.head.next
            return
        count = 0
        temp = self.head
        while temp:
            if count == index - 1:  # for removing prior index
                temp.next = temp.next.next  # it's pointing to next of next
                break
            temp = temp.next
            count += 1


    def insert_at(self, index, data):
        if index < 0 or index >= self.get_length():
            raise Exception("invalid index")

        if index == 0:
            self.insert_at_begining(data)
            return
        count = 0
        temp = self.head
        while temp:
            if count == index - 1:
                node = Node(data, temp.next)  # creating the node because pervious element nodes next is next of new node
                temp.next = node
                break
            temp = temp.next
            count += 1


if __name__ == '__main__':
    ll = Linkedlist()
    ll.insert_at_begining(2)
    ll.insert_at_begining(1)
    ll.insert_at_end(3)
    ll.insert_at_end(4)
    ll.insert_values(['a', 'b', 'c'])
    ll.print()
    print("length", ll.get_length())
    ll.remove_at(1)
    ll.insert_at(1, 'z')
    ll.print()