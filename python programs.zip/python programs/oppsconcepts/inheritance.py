#simple example of parent and child class for inheritance

class Person:
    def __init__(self,name,idnumber):
        self.name=name
        self.idnumber=idnumber

    def display(self):
        print(self.name)
        print(self.idnumber)

    def details(self):
        print("my name is:",self.name)
        print("my id idnumber is:",self.idnumber)


class Employee(Person):
    def __init__(self,name,idnumber,salary,role):
        self.salary = salary
        self.role = role

        Person.__init__(self,name,idnumber)    #or super().__init__(name,idnumber)


    def details(self):
        print("my name is:",self.name)
        print("my id idnumber is:",self.idnumber)
        print("my salary is:",self.salary)
        print("my role is",self.role)

a = Employee("abc",1234,40000,"intern")
a.display()
a.details()