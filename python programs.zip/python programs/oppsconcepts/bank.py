# create account class with 2 attribute balance and account no and create the method for debit,credit and printing the balance
class Account:
    def __init__(self, bal, acc):
        self.balance = bal
        self.accountno = acc

    def debit(self, amount):
        self.balance -= amount
        print("rs.", amount, "was debitted")
        print("total balance is", self.get_balance())

    def credit(self, amount):
        self.balance += amount
        print("rs.", amount, "was credited")
        print("total balance is", self.get_balance())

    def get_balance(self):
        return self.balance


Acc1 = Account(10000, 12345)
print(Acc1.balance)
print(Acc1.accountno)

Acc1.credit(1000)
Acc1.debit(2000)
