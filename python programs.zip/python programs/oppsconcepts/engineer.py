# wap to create employee class also create engineer class inheriting properties of employee class

class Employee:
    def __init__(self, role, department, salary):
        self.role = role
        self.dept = department
        self.salary = salary

    def show_details(self):
        print("role =", self.role)
        print("department =", self.dept)
        print("salary =", self.salary)


class Engineer(Employee):
    def __init__(self, name, age):
        self.name = name
        self.age = age
        super().__init__("Engineer", "def", "80000")


e1 = Engineer("aaa", 23)
e1.show_details()

