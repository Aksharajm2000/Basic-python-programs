# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
# wap to create student class the takes name and marks of 3 subject as arguement in constructor and create a method to print the average

class Students:

    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def get_avg(self):
        sum = 0
        for val in self.marks:
            sum += val
        print("hi", self.name, "your average is", sum / 3)

    @staticmethod
    def hello():
        print("hello")


s1 = Students("abc", [98, 75, 85])
s1.get_avg()
s1.name = "def"
s1.marks = [98, 89, 60]
s1.get_avg()
s1.hello()

